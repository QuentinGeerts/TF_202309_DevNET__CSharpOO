﻿namespace GestionBanque.Exemples
{
    internal interface IForme
    {
        int Aire();
        string getNom();
        void setNom(string n);
    }
}